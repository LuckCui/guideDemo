//
//  GuidePageVC.h
//  yindaoye
//
//  Created by Apple on 16/4/8.
//  Copyright © 2016年 CJZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GuidePageVC : UIViewController

@end
