//
//  GuidePageVC.m
//  yindaoye
//
//  Created by Apple on 16/4/8.
//  Copyright © 2016年 CJZ. All rights reserved.
//

#import "GuidePageVC.h"
#import "ViewController.h"
#import "AppDelegate.h"

#define viewW [UIScreen mainScreen].bounds.size.width
#define viewH [UIScreen mainScreen].bounds.size.height
#define tabBarItemTextColor [UIColor colorWithRed:0.93 green:0.4 blue:0.53 alpha:1]

@interface GuidePageVC ()<UIScrollViewDelegate>

@property (nonatomic, strong) NSMutableArray *imageDataArray;
@property (nonatomic, strong) UIPageControl *pageControl;

@end

@implementation GuidePageVC

- (NSMutableArray *)imageDataArray {
    
    if (_imageDataArray == nil) {
        
        _imageDataArray = [NSMutableArray arrayWithObjects:@"functionTip1.jpg",@"functionTip2.jpg",@"functionTip3.jpg",@"functionTip4.jpg",@"functionTip5.jpg",@"functionTip6.jpg", nil];
    }
 
    return _imageDataArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self setUIScorllView];
    
    //创建分页器
    _pageControl = [[UIPageControl alloc]initWithFrame:CGRectMake(0, 0, 50, 20)];
    _pageControl.center = CGPointMake(viewW * 0.5, viewH - 50);
    _pageControl.currentPage = 0;
    _pageControl.numberOfPages = 6;
    //选中状态颜色
    [_pageControl setCurrentPageIndicatorTintColor:tabBarItemTextColor];
    //未选中状态颜色
    [_pageControl setPageIndicatorTintColor:[UIColor grayColor]];
    
    [self.view addSubview:_pageControl];

}

//创建图片轮换View
- (void)setUIScorllView  {
    
    UIScrollView *scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, viewW, viewH)];
    scrollView.delegate = self;
    scrollView.pagingEnabled = YES;
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.showsVerticalScrollIndicator   = NO;
    scrollView.contentSize = CGSizeMake(self.imageDataArray.count * viewW, viewH);
    
    for (int i = 0; i < self.imageDataArray.count; i++) {
        
        UIImageView *imageV = [[UIImageView alloc]initWithFrame:CGRectMake(i * viewW, 0, viewW, viewH)];
        imageV.image = [UIImage imageNamed:self.imageDataArray[i]];
        [scrollView addSubview:imageV];
        
        if (i == self.imageDataArray.count - 1) {
            
            imageV.userInteractionEnabled = YES;
            UIButton *but = [UIButton buttonWithType:UIButtonTypeCustom];
            but.frame = CGRectMake(0 ,0 , 100, 30);
            but.center = CGPointMake(viewW * 0.5, viewH - 200);
            [but setTitleColor:[UIColor purpleColor] forState:UIControlStateNormal];
            [but setTitle:@"进去主界面" forState:UIControlStateNormal];
            [but  addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
            [imageV addSubview:but];
            
        }
        
        [self.view addSubview:scrollView];

    }

}

//点击马上体验的时候

- (void)btnClick:(UIButton *)sender {
    
    //赋值
    NSUserDefaults *user = [NSUserDefaults standardUserDefaults];
    [user setObject:@"YES" forKey:@"isYes"];
    
    //改变根控制器
   AppDelegate *delegate = [UIApplication sharedApplication].delegate;
    UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    delegate.window.rootViewController = [sb instantiateInitialViewController];
    
}

#pragma mark - UIScrollViewDelegate
//获取当前页数
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
    CGFloat scrollViewW = scrollView.frame.size.width;//sView的总体宽度
    CGFloat x = scrollView.contentOffset.x;//内容的左上角标点；
    //页数 = （内容视图X + SView的总体宽度 /2）除以 总体宽度
    int page = (x + scrollViewW/2)/scrollViewW;
    _pageControl.currentPage = page;
    
}

@end
